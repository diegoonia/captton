﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
*
*
* Trabajo Practico Integrador - Semana 1
* Oña, Diego
*
*
*/
namespace ProyectoDia05
{
    class Servicio : Producto
    {

        public Servicio(int codigo, string nombre, float precio) : base(codigo, nombre, precio)
        {

        }

        
    }
}
